﻿using System.Collections;
using System;


public class IgnoreEntityMemberAttribute : Attribute
{

}
 